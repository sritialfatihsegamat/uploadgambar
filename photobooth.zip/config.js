// Tampal pautan Apps Script (yang berakhir dengan /exec) antara tanda petik di bawah.
window.CONFIG = { UPLOAD_URL: "PASTE_LINK_EXEC_DI_SINI" };
